[[ ! -r "$HOME/.bashrc" ]] || . "$HOME/.bashrc"
export PATH="$HOME/.local/share/shadow-link/bin:$HOME/.local/bin:/usr/bin:/bin:$PATH"
export LANG=en_US.UTF-8
export LC_CTYPE=en_US.UTF-8
case "$(cat "$HOME/.config/shadowrealm-os/appearance-mode" 2>/dev/null)" in
  neon) PS1='\[\e[38;2;0;238;255m\][\u@\h \w]\$ \[\e[0m\]';;
  *) PS1='[\u@\h \w]\$ ';;
esac
